DLUVTYPEBEATS starter website

Files:
- index.html: responsive, static website landing page.

Free hosting:
1. Create a GitHub account and a new public repository.
2. Upload index.html to the repository root.
3. In Settings > Pages, choose Deploy from a branch, select main and /(root), then Save.
4. GitHub Pages will provide a free public URL. A custom domain such as dluvbeats.com usually costs money to register.

Before taking payments:
- Create Stripe Payment Links for each package ($75, $150, $300, $500).
- Replace each package button's href="#checkout-setup" in index.html with its corresponding Stripe URL.
- Configure receipts/checkout email collection in Stripe.
- Set up a secure email delivery process for purchased beat files and license terms. This starter page does not process payments or automatically send beat files yet.
- Add contact details, licensing terms, privacy policy, and refund policy.
